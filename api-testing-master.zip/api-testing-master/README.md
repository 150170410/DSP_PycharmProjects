# api-testing
API test-suite using Python (Unit-Test, Requests) and Java BDD (Maven, Rest Assured, Junit)

# REST API Test:
* Please automate tests for the API Resource http://jsonplaceholder.typicode.com/posts
* Operation to be covered:  Create, Update, View, Delete, List
* For further details refer to: https://github.com/typicode/jsonplaceholder
* Explain your framework architecture and design considerations
